Metadata-Version: 2.1
Name: mfyreport
Version: 0.0.2
Summary: UNKNOWN
Home-page: https://github.com/mfy/mfyreport
Author: MingFeiyang
Author-email: mfy1102@163.com
License: UNKNOWN
Platform: UNKNOWN
Classifier: Programming Language :: Python :: 3
Requires-Python: >=3.6
Description-Content-Type: text/markdown
Requires-Dist: Jinja2 (==2.10.1)
Requires-Dist: PyYAML (==5.3.1)
Requires-Dist: requests (==2.24.0)